package com.pcb.offline;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView webView;
    private LocalDb db;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_PICKER = 42;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        db = new LocalDb(this);
        webView = new WebView(this);
        setContentView(webView);

        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowContentAccess(true);
        webView.setWebViewClient(new AppWebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("image/*");
                startActivityForResult(intent, FILE_PICKER);
                return true;
            }
        });
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidDB");
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_PICKER && fileCallback != null) {
            Uri[] result = (resultCode == RESULT_OK && data != null && data.getData() != null) ? new Uri[]{data.getData()} : null;
            fileCallback.onReceiveValue(result);
            fileCallback = null;
        }
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    private class AppWebViewClient extends WebViewClient {
        @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            if (request.isForMainFrame() && request.getUrl().toString().endsWith("/index.html")) {
                try {
                    InputStream in = getAssets().open("index.html");
                    String html = readAll(in, StandardCharsets.UTF_8);
                    String bridge = """
<script>
(function(){
  const nativeStore = window.AndroidDB;
  const storage = {
    get length(){ return Number(nativeStore.count()); },
    key: function(i){ return nativeStore.keyAt(Number(i)); },
    getItem: function(k){ const v=nativeStore.getItem(String(k)); return v===null ? null : String(v); },
    setItem: function(k,v){ nativeStore.setItem(String(k), String(v)); },
    removeItem: function(k){ nativeStore.removeItem(String(k)); },
    clear: function(){ nativeStore.clear(); }
  };
  Object.defineProperty(window, 'localStorage', {value: storage, configurable:false});
  window.print = function(){ nativeStore.printPage(); };
})();
</script>
""";
                    html = html.replace("</head>", bridge + "</head>");
                    return new WebResourceResponse("text/html", "UTF-8", new ByteArrayInputStream(html.getBytes(StandardCharsets.UTF_8)));
                } catch (Exception e) { return null; }
            }
            return super.shouldInterceptRequest(view, request);
        }
    }

    public class AndroidBridge {
        @JavascriptInterface public String getItem(String key) { return db.get(key); }
        @JavascriptInterface public void setItem(String key, String value) { db.put(key, value); }
        @JavascriptInterface public void removeItem(String key) { db.remove(key); }
        @JavascriptInterface public void clear() { db.clear(); }
        @JavascriptInterface public int count() { return db.count(); }
        @JavascriptInterface public String keyAt(int index) { return db.keyAt(index); }
        @JavascriptInterface public void printPage() {
            runOnUiThread(() -> {
                PrintManager pm = (PrintManager)getSystemService(PRINT_SERVICE);
                String job = "Nota PCB Offline";
                pm.print(job, webView.createPrintDocumentAdapter(job), new PrintAttributes.Builder()
                        .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                        .build());
            });
        }
    }

    private static String readAll(InputStream in, java.nio.charset.Charset cs) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] b = new byte[8192]; int n;
        while ((n=in.read(b))!=-1) out.write(b,0,n);
        return out.toString(cs.name());
    }

    static class LocalDb extends SQLiteOpenHelper {
        LocalDb(android.content.Context c) { super(c, "pcb_offline.db", null, 1); }
        @Override public void onCreate(SQLiteDatabase d) { d.execSQL("CREATE TABLE kv (k TEXT PRIMARY KEY, v TEXT NOT NULL)"); }
        @Override public void onUpgrade(SQLiteDatabase d, int oldV, int newV) {}
        synchronized String get(String k) { Cursor c=getReadableDatabase().query("kv",new String[]{"v"},"k=?",new String[]{k},null,null,null); try{return c.moveToFirst()?c.getString(0):null;}finally{c.close();} }
        synchronized void put(String k,String v){getWritableDatabase().execSQL("INSERT OR REPLACE INTO kv(k,v) VALUES(?,?)",new Object[]{k,v});}
        synchronized void remove(String k){getWritableDatabase().delete("kv","k=?",new String[]{k});}
        synchronized void clear(){getWritableDatabase().delete("kv",null,null);}
        synchronized int count(){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM kv",null);try{c.moveToFirst();return c.getInt(0);}finally{c.close();}}
        synchronized String keyAt(int i){Cursor c=getReadableDatabase().query("kv",new String[]{"k"},null,null,null,null,"rowid ASC",i+",1");try{return c.moveToFirst()?c.getString(0):null;}finally{c.close();}}
    }
}
