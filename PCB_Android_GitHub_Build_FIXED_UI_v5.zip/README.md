# PCB Offline Android - FIXED UI

Project Android WebView offline untuk aplikasi PCB Offline.

## Perbaikan utama
- HTML versi `pcb_final_revisi_6.html` dipakai sebagai UI utama.
- Tailwind CDN dan FontAwesome CDN dihapus agar UI tidak bergantung internet.
- CSS utility yang digunakan HTML dibundel lokal di `assets/offline.css`.
- LocalStorage tetap digunakan untuk data aplikasi.
- Upload logo memakai file chooser Android.
- Tombol cetak diteruskan ke Android Print Framework.
- GitHub Actions siap build APK tanpa komputer.

## Build di GitHub
Push seluruh isi repository, lalu buka Actions > Build PCB Offline APK. Setelah hijau, buka run tersebut dan download artifact `PCB-Offline-APK-FIXED`.
